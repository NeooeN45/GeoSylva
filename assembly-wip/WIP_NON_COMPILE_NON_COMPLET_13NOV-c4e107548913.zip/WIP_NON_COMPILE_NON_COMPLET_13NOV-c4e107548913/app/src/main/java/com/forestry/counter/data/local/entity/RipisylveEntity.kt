package com.forestry.counter.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.forestry.counter.domain.model.ripisylve.InadapteesMode
import com.forestry.counter.domain.model.ripisylve.LargeurMode
import com.forestry.counter.domain.model.ripisylve.RipisylveObservation

@Entity(
    tableName = "ripisylve_observation",
    foreignKeys = [
        ForeignKey(
            entity = ParcelleEntity::class,
            parentColumns = ["parcelleId"],
            childColumns = ["parcelleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(name = "index_ripisylve_parcelleId", value = ["parcelleId"])]
)
data class RipisylveEntity(
    @PrimaryKey val id: String,
    val parcelleId: String,
    val observerName: String,
    val observationDate: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val isDraft: Boolean,
    val photosJson: String,
    val latitude: Double?,
    val longitude: Double?,
    val altitudeM: Double?,
    val sectionLengthM: Double,
    val sectionNotes: String,
    val continuitePct: Double,
    val largeurMode: String,
    val strateHerbacee: Boolean,
    val strateArbustive: Boolean,
    val strateArborescente: Boolean,
    val nbEspecesObservees: Int,
    val especesObserveesCsv: String,
    val diamAutoFromDendro: Boolean,
    val hasTresPetitBois: Boolean,
    val hasPetitBois: Boolean,
    val hasMoyenBois: Boolean,
    val hasGrosBois: Boolean,
    val microhabitatCavites: Boolean,
    val microhabitatFissures: Boolean,
    val microhabitatDecollementEcorce: Boolean,
    val microhabitatChampignons: Boolean,
    val microhabitatBoisMort: Boolean,
    val microhabitatTresGrosBois: Boolean,
    val sanitairePct: Double,
    val invasivesPct: Double,
    val invasivesCsv: String,
    val inadapteesMode: String,
    val stabilitePct: Double,
    val globalNotes: String,

    // Metadata spec GeoSylva 3.0 (GEOSYLVA-003 §3.1)
    val deletedAt: Long? = null,
    val auteur: String? = null,
    val source: String? = null,
    @ColumnInfo(name = "version", defaultValue = "1")
    val version: Int = 1
) {
    fun toDomain(): RipisylveObservation = RipisylveObservation(
        id = id,
        parcelleId = parcelleId,
        observerName = observerName,
        observationDate = observationDate,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isDraft = isDraft,
        latitude = latitude,
        longitude = longitude,
        altitudeM = altitudeM,
        sectionLengthM = sectionLengthM,
        sectionNotes = sectionNotes,
        continuitePct = continuitePct,
        largeurMode = LargeurMode.entries.firstOrNull { it.name == largeurMode } ?: LargeurMode.UNE_RANGEE,
        strateHerbacee = strateHerbacee,
        strateArbustive = strateArbustive,
        strateArborescente = strateArborescente,
        nbEspecesObservees = nbEspecesObservees,
        especesObservees = if (especesObserveesCsv.isBlank()) emptyList() else especesObserveesCsv.split(","),
        diamAutoFromDendro = diamAutoFromDendro,
        hasTresPetitBois = hasTresPetitBois,
        hasPetitBois = hasPetitBois,
        hasMoyenBois = hasMoyenBois,
        hasGrosBois = hasGrosBois,
        microhabitatCavites = microhabitatCavites,
        microhabitatFissures = microhabitatFissures,
        microhabitatDecollementEcorce = microhabitatDecollementEcorce,
        microhabitatChampignons = microhabitatChampignons,
        microhabitatBoisMort = microhabitatBoisMort,
        microhabitatTresGrosBois = microhabitatTresGrosBois,
        sanitairePct = sanitairePct,
        invasivesPct = invasivesPct,
        invasivesIdentifiees = if (invasivesCsv.isBlank()) emptyList() else invasivesCsv.split(","),
        inadapteesMode = InadapteesMode.entries.firstOrNull { it.name == inadapteesMode } ?: InadapteesMode.ABSENCE,
        stabilitePct = stabilitePct,
        globalNotes = globalNotes,
        deletedAt = deletedAt,
        auteur = auteur,
        source = source,
        version = version
    )

    companion object {
        fun fromDomain(obs: RipisylveObservation): RipisylveEntity = RipisylveEntity(
            id = obs.id,
            parcelleId = obs.parcelleId,
            observerName = obs.observerName,
            observationDate = obs.observationDate,
            createdAt = obs.createdAt,
            updatedAt = obs.updatedAt,
            isDraft = obs.isDraft,
            photosJson = "[]",
            latitude = obs.latitude,
            longitude = obs.longitude,
            altitudeM = obs.altitudeM,
            sectionLengthM = obs.sectionLengthM,
            sectionNotes = obs.sectionNotes,
            continuitePct = obs.continuitePct,
            largeurMode = obs.largeurMode.name,
            strateHerbacee = obs.strateHerbacee,
            strateArbustive = obs.strateArbustive,
            strateArborescente = obs.strateArborescente,
            nbEspecesObservees = obs.nbEspecesObservees,
            especesObserveesCsv = obs.especesObservees.joinToString(","),
            diamAutoFromDendro = obs.diamAutoFromDendro,
            hasTresPetitBois = obs.hasTresPetitBois,
            hasPetitBois = obs.hasPetitBois,
            hasMoyenBois = obs.hasMoyenBois,
            hasGrosBois = obs.hasGrosBois,
            microhabitatCavites = obs.microhabitatCavites,
            microhabitatFissures = obs.microhabitatFissures,
            microhabitatDecollementEcorce = obs.microhabitatDecollementEcorce,
            microhabitatChampignons = obs.microhabitatChampignons,
            microhabitatBoisMort = obs.microhabitatBoisMort,
            microhabitatTresGrosBois = obs.microhabitatTresGrosBois,
            sanitairePct = obs.sanitairePct,
            invasivesPct = obs.invasivesPct,
            invasivesCsv = obs.invasivesIdentifiees.joinToString(","),
            inadapteesMode = obs.inadapteesMode.name,
            stabilitePct = obs.stabilitePct,
            globalNotes = obs.globalNotes,
            deletedAt = obs.deletedAt,
            auteur = obs.auteur,
            source = obs.source,
            version = obs.version
        )
    }
}
